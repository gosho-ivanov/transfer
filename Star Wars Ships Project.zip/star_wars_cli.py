
import json
from star_wars_simulator import ShipFactory, Alliance, SHIP_REGISTRY, Battle

STATE_FILE = "fleet_state.json"

def load_state():
    try:
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    except:
        return {}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def add_ship(state):
    try:
        print("Available ship types:")
        for s in SHIP_REGISTRY:
            print("-", s)
        t = input("Enter ship type: ").upper()
        n = input("Enter ship name: ")
        ship = ShipFactory.create(t, n)
        state[n] = {"type": t, "alliance": ship.alliance.value}
        save_state(state)
    except:
        print("Error adding ship")

def delete_ship(state):
    n = input("Enter ship name to delete: ")
    if n in state:
        del state[n]
        save_state(state)
    else:
        print("Ship not found")

def list_ships(state):
    for n, d in state.items():
        print(f"{n} [{d['alliance']}] ({d['type']})")

def battle_ships(state):
    names = input("Enter ship names (comma-separated): ").split(",")
    ships = []
    for n in names:
        n = n.strip()
        if n in state:
            ships.append(ShipFactory.create(state[n]["type"], n))
    if len(ships) >= 2:
        Battle(ships).run()

def main():
    state = load_state()
    while True:
        print("1. Add ship")
        print("2. Delete ship")
        print("3. Show all ships")
        print("4. Battle ships")
        print("5. Exit")
        try:
            c = int(input("Choose: "))
            if c == 1: add_ship(state)
            elif c == 2: delete_ship(state)
            elif c == 3: list_ships(state)
            elif c == 4: battle_ships(state)
            elif c == 5: break
        except:
            print("Invalid input")

if __name__ == "__main__":
    main()
