
from __future__ import annotations
from abc import ABC, abstractmethod
from enum import Enum
import random

class Alliance(Enum):
    REBELS = "Rebels"
    EMPIRE = "Empire"

class Battleship(ABC):
    def __init__(self, name, alliance, shield, hull, dmg, speed, hyperspace):
        self.name = name
        self.alliance = alliance
        self.shield = shield
        self.hull = hull
        self.dmg = dmg
        self.speed = speed
        self.hyperspace = hyperspace

    @property
    def alive(self):
        return self.hull > 0

    def receive_damage(self, dmg):
        if self.shield > 0:
            absorbed = min(self.shield, dmg)
            self.shield -= absorbed
            dmg -= absorbed
        self.hull = max(0, self.hull - dmg)

    def can_attack(self, other):
        return self.alive and other.alive and self.alliance != other.alliance

    @abstractmethod
    def fight(self, enemy):
        pass

class RebelShip(Battleship):
    def __init__(self, **kw):
        super().__init__(alliance=Alliance.REBELS, **kw)

class EmpireShip(Battleship):
    def __init__(self, **kw):
        super().__init__(alliance=Alliance.EMPIRE, **kw)

class XWing(RebelShip):
    def fight(self, enemy):
        if self.can_attack(enemy):
            enemy.receive_damage(self.dmg + random.randint(5, 15))

class StarDestroyer(EmpireShip):
    def fight(self, enemy):
        if self.can_attack(enemy):
            enemy.receive_damage(self.dmg * 3)

SHIP_REGISTRY = {
    "X_WING": XWing,
    "STAR_DESTROYER": StarDestroyer,
}

SHIP_STATS = {
    "X_WING": dict(shield=100, hull=120, dmg=40, speed=120, hyperspace=True),
    "STAR_DESTROYER": dict(shield=500, hull=1000, dmg=30, speed=40, hyperspace=True),
}

class ShipFactory:
    @staticmethod
    def create(ship_type, name):
        cls = SHIP_REGISTRY[ship_type]
        return cls(name=name, **SHIP_STATS[ship_type])

class Battle:
    def __init__(self, ships):
        self.ships = ships

    def run(self):
        round_no = 1
        while True:
            rebels = [s for s in self.ships if s.alive and s.alliance == Alliance.REBELS]
            empire = [s for s in self.ships if s.alive and s.alliance == Alliance.EMPIRE]
            if not rebels or not empire:
                break
            random.shuffle(self.ships)
            for s in self.ships:
                enemies = [e for e in self.ships if s.can_attack(e)]
                if enemies:
                    s.fight(random.choice(enemies))
            round_no += 1
